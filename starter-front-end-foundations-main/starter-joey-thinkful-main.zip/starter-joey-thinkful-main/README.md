# starter-joey-thinkful

This repo contains the starter and solution code for the Joey Thinkful resume exercise.
